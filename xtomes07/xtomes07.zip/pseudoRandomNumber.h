

#ifndef pseudorandomNumber_H_
#define pseudorandomNumber_H_

#include <std.h>

Int32 getRandomNumber();

#endif /* GENERATE_H_ */
